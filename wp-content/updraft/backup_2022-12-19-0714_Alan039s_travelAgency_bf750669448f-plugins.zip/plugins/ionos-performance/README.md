# IONOS Performance
A plugin that bundles performance-related features.

## Features
- HDD Caching