<?php /* CWSD Guarder */
is_file("/opt/lampp/htdocs/travelAgency/wp-content/plugins/cwis-antivirus-malware-detected/cwsd-block.php") AND include_once "/opt/lampp/htdocs/travelAgency/wp-content/plugins/cwis-antivirus-malware-detected/cwsd-block.php";
?>

<?php
// Silence is golden.
