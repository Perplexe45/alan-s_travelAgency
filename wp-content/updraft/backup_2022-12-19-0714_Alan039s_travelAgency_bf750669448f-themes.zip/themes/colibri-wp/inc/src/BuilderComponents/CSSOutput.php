<?php

namespace ColibriWP\Theme\BuilderComponents;


use ColibriWP\Theme\Core\ComponentBase;

class CssOutput extends ComponentBase {

    public function renderContent() {

    }

    /**
     * @return array();
     */
    protected static function getOptions() {

    }
}
