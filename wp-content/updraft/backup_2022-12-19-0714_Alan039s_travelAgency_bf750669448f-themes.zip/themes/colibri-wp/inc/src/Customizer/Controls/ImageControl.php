<?php


namespace ColibriWP\Theme\Customizer\Controls;


use WP_Customize_Image_Control;

class ImageControl extends WP_Customize_Image_Control {

    use ColibriWPControlsAdapter;
}
