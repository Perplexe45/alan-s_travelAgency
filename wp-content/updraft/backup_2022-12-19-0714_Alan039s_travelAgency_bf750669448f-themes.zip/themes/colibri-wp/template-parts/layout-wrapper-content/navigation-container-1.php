<div data-colibri-id="432-m20" class="h-row-container gutters-row-lg-0 gutters-row-md-0 gutters-row-0 gutters-row-v-lg-0 gutters-row-v-md-0 gutters-row-v-0 style-560 style-local-432-m20 position-relative">
  <div class="h-row justify-content-lg-center justify-content-md-center justify-content-center align-items-lg-stretch align-items-md-stretch align-items-stretch gutters-col-lg-0 gutters-col-md-0 gutters-col-0 gutters-col-v-lg-0 gutters-col-v-md-0 gutters-col-v-0">
    <div class="h-column h-column-container d-flex h-col-lg-auto h-col-md-auto h-col-auto style-561-outer style-local-432-m21-outer">
      <div data-colibri-id="432-m21" class="d-flex h-flex-basis h-column__inner h-px-lg-0 h-px-md-0 h-px-0 v-inner-lg-2 v-inner-md-2 v-inner-2 style-561 style-local-432-m21 position-relative">
        <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-start align-self-md-start align-self-start">
          <div data-colibri-id="432-m22" class="post-nav-button hide-title style-562 style-local-432-m22 position-relative h-element">
            <div class="h-global-transition-all">
              <?php colibriwp_post_nav_button(array (
                'type' => 'prev',
                'prev_post' => __('Previous post', 'colibri-wp'),
                'next_post' => __('Next post:', 'colibri-wp'),
                'show_title' => false,
                'title_length' => 40,
              )); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="h-column h-column-container d-flex h-col-lg-auto h-col-md-auto h-col-auto style-563-outer style-local-432-m23-outer">
      <div data-colibri-id="432-m23" class="d-flex h-flex-basis h-column__inner h-px-lg-0 h-px-md-0 h-px-0 v-inner-lg-2 v-inner-md-2 v-inner-2 style-563 style-local-432-m23 position-relative">
        <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-start align-self-md-start align-self-start">
          <div data-colibri-id="432-m24" class="post-nav-button hide-title style-564 style-local-432-m24 position-relative h-element">
            <div class="h-global-transition-all">
              <?php colibriwp_post_nav_button(array (
                'type' => 'next',
                'prev_post' => __('Previous post:', 'colibri-wp'),
                'next_post' => __('Next post', 'colibri-wp'),
                'show_title' => false,
                'title_length' => 30,
              )); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
