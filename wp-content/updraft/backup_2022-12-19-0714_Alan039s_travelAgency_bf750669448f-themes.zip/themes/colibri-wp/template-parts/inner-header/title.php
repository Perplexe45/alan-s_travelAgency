<div data-colibri-id="10-h28" class="page-title style-194 style-local-10-h28 position-relative h-element">
  <?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
  <div class="h-global-transition-all">
    <?php colibriwp_page_title(array (
      'tag' => 'h1',
    )); ?>
  </div>
</div>
