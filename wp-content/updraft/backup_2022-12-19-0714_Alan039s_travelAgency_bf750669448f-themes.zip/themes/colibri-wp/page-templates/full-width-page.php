<?php
/*
 * Template Name: Full Width Template
 */
get_header();
?>
<?php colibriwp_theme()->get( 'front-page-content' )->render(); ?>

<?php get_footer();
